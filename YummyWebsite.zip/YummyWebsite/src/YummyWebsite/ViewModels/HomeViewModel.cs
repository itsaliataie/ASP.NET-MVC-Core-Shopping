﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using YummyWebsite.Models;

namespace YummyWebsite.ViewModels
{
    public class HomeViewModel
    {
        public IEnumerable<Food> FoodsOfTheWeek { get; set; }
    }
}
