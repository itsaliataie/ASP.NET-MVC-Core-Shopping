﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace YummyWebsite.Models
{
    public class MockCategoryRepository: ICategoryRepository
    {
        public IEnumerable<Category> Categories
        {
            get
            {
                return new List<Category>
                {
                    new Category{CategoryId=1, CategoryName="Pizza", Description="All Types of Pizza"},
                    new Category{CategoryId=2, CategoryName="Burgers", Description="All Types of Burgers"},
                    new Category{CategoryId=3, CategoryName="Fry", Description="Everything Fried"}
                };
            }
        }
    }
}
