﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace YummyWebsite.Models
{
    public class MockFoodRepository: IFoodRepository
    {
        private readonly ICategoryRepository _categoryRepository = new MockCategoryRepository();


        public IEnumerable<Food> Foods
        {
            get
            {
                return new List<Food>
                {
                    new Food {FoodId = 1, Name="Yummy Pizza", Price=150M, ShortDescription="Special Yummy Pizza", LongDescription="Pizza prices are based on size: Kids: 150 afs, Small - 390 afs, Medium - 490 afs, Large - 590 -- Cheese, Sauce, Olive, Chicken, Mushroom, Pineapple, Sausage", Category = _categoryRepository.Categories.ToList()[0],ImageUrl="http://www.yummy.af/yummy_cms/images/foods/Yummy_Pizza.jpg", InStock=true, IsFoodOfTheWeek=false, ImageThumbnailUrl="http://www.yummy.af/yummy_cms/images/foods/Yummy_Pizza.jpg"},
                    new Food {FoodId = 2, Name="Beef Burger", Price=200M, ShortDescription="Beef Burger", LongDescription="No Food Description.", Category = _categoryRepository.Categories.ToList()[1],ImageUrl="http://www.yummy.af/yummy_cms/images/foods/7.jpg", InStock=true, IsFoodOfTheWeek=false, ImageThumbnailUrl="http://www.yummy.af/yummy_cms/images/foods/7.jpg"},
                    new Food {FoodId = 3, Name="Chicken Burger", Price=200M, ShortDescription="Chicken Burger", LongDescription="No Food Description.", Category = _categoryRepository.Categories.ToList()[1],ImageUrl="http://www.yummy.af/yummy_cms/images/foods/Chicken_Burger.jpg", InStock=true, IsFoodOfTheWeek=true, ImageThumbnailUrl="http://www.yummy.af/yummy_cms/images/foods/Chicken_Burger.jpg"},
                    new Food {FoodId = 4, Name="Chicken Wings", Price=180M, ShortDescription="Special Yummy Pizza", LongDescription="Plain, Hot, Yummy, B.B.Q 12 ps", Category = _categoryRepository.Categories.ToList()[2],ImageUrl="http://www.yummy.af/yummy_cms/images/foods/12.jpg", InStock=true, IsFoodOfTheWeek=true, ImageThumbnailUrl="http://www.yummy.af/yummy_cms/images/foods/12.jpg"}
                };
            }
        }

        public IEnumerable<Food> FoodsOfTheWeek { get; }

        public Food GetFoodById(int foodId)
        {
            throw new NotImplementedException();
        }
    }
}
