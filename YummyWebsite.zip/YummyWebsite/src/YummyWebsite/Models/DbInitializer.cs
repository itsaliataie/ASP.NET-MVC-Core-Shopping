﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace YummyWebsite.Models
{
    public static class DbInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            AppDbContext context = applicationBuilder.ApplicationServices.GetRequiredService<AppDbContext>();

            if (!context.Categories.Any())
            {
                context.Categories.AddRange(Categories.Select(c => c.Value));
            }

            if (!context.Foods.Any())
            {
                context.AddRange
                (
                    new Food { Name = "Yummy Pizza", Price = 150M, ShortDescription = "Special Yummy Pizza", LongDescription = "Pizza prices are based on size: Kids: 150 afs, Small - 390 afs, Medium - 490 afs, Large - 590 -- Cheese, Sauce, Olive, Chicken, Mushroom, Pineapple, Sausage", Category = Categories["Pizza"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/Yummy_Pizza.jpg", InStock = true, IsFoodOfTheWeek = true, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/Yummy_Pizza.jpg", AllergyInformation = "" },
                    new Food { Name = "Chicken Fajitas Pizza", Price = 150M, ShortDescription = "You'll love it!", LongDescription = "Kids: 150 afs - Small: 390 afs - Medium: 490 afs - Large: 590 afs", Category = Categories["Pizza"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/17.jpg", InStock = true, IsFoodOfTheWeek = false, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/17.jpg", AllergyInformation = "" },
                    new Food { Name = "Margarita Pizza", Price = 150M, ShortDescription = "A pizza with Margarita", LongDescription = "Kids: 150 afs - Small: 390 afs - Medium: 490 afs - Large: 590 afs", Category = Categories["Pizza"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/25.jpg", InStock = true, IsFoodOfTheWeek = false, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/25.jpg", AllergyInformation = "" },
                    new Food { Name = "Pepperoni Pizza", Price = 150M, ShortDescription = "A summer classic!", LongDescription = "Kids: 150 afs - Small: 390 afs - Medium: 490 afs - Large: 590 afs", Category = Categories["Pizza"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/13.jpg", InStock = true, IsFoodOfTheWeek = false, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/13.jpg", AllergyInformation = "" },
                    new Food { Name = "Zinger Burger", Price = 190M, ShortDescription = "Happy holidays with this burger!", LongDescription = "No Food Description.", Category = Categories["Burgers"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/Zinger_Burger.jpeg", InStock = true, IsFoodOfTheWeek = false, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/Zinger_Burger.jpeg", AllergyInformation = "" },
                    new Food { Name = "Chicken Burger", Price = 190M, ShortDescription = "A holiday favorite", LongDescription = "No Food Description.", Category = Categories["Burgers"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/Chicken_Burger.jpg", InStock = true, IsFoodOfTheWeek = false, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/Chicken_Burger.jpg", AllergyInformation = "" },
                    new Food { Name = "Beef Burger", Price = 200M, ShortDescription = "Amazing", LongDescription = "No Food Description.", Category = Categories["Burgers"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/7.jpg", InStock = false, IsFoodOfTheWeek = false, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/7.jpg", AllergyInformation = "" },
                    new Food { Name = "Fish Burger", Price = 210M, ShortDescription = "Our Eid favorite", LongDescription = "No Food Description.", Category = Categories["Burgers"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/fishburger.png", InStock = true, IsFoodOfTheWeek = true, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/fishburger.png", AllergyInformation = "" },
                    new Food { Name = "Fried Chicken", Price = 200M, ShortDescription = "So delicious", LongDescription = "Chicken, Breading, French Fries, Salad, Bread", Category = Categories["Fry"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/DSC_7105.JPG", InStock = true, IsFoodOfTheWeek = true, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/DSC_7105.JPG", AllergyInformation = "" },
                    new Food { Name = "Chicken Wings", Price = 180M, ShortDescription = "Wings", LongDescription = "Plain, Hot, Yummy, B.B.Q 12 ps", Category = Categories["Fry"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/DSC_6941.JPG", InStock = true, IsFoodOfTheWeek = false, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/DSC_6941.JPG", AllergyInformation = "" },
                    new Food { Name = "Fish Fry", Price = 210M, ShortDescription = "You'll love it!", LongDescription = "Fish, Breading, French fries, Bread", Category = Categories["Fry"], ImageUrl = "http://www.yummy.af/yummy_cms/images/foods/DSC_6919.JPG", InStock = false, IsFoodOfTheWeek = false, ImageThumbnailUrl = "http://www.yummy.af/yummy_cms/images/foods/DSC_6919.JPG", AllergyInformation = "" }
                );
            }

            context.SaveChanges();
        }

        private static Dictionary<string, Category> categories;
        public static Dictionary<string, Category> Categories
        {
            get
            {
                if (categories == null)
                {
                    var genresList = new Category[]
                    {
                        new Category { CategoryName = "Pizza" }, 
                        new Category { CategoryName = "Burgers" },
                        new Category { CategoryName = "Fry" },
                    };

                    categories = new Dictionary<string, Category>();

                    foreach (Category genre in genresList)
                    {
                        categories.Add(genre.CategoryName, genre);
                    }
                }

                return categories;
            }
        }
    }
}
