﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using YummyWebsite.Models;
using YummyWebsite.ViewModels;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace YummyWebsite.Controllers
{
    public class FoodController : Controller
    {
        private readonly IFoodRepository _foodRepository;
        private readonly ICategoryRepository _categoryRepository;

        public FoodController(IFoodRepository foodRepository, ICategoryRepository categoryRepository)
        {
            _foodRepository = foodRepository;
            _categoryRepository = categoryRepository;
        }

        public ViewResult List(string category)
        {
            IEnumerable<Food> foods;
            string currentCategory = string.Empty;

            if (string.IsNullOrEmpty(category))
            {
                foods = _foodRepository.Foods.OrderBy(f => f.FoodId);
                currentCategory = "All foods";
            }
            else
            {
                foods = _foodRepository.Foods.Where(f => f.Category.CategoryName == category)
                    .OrderBy(f => f.FoodId);
                currentCategory = _categoryRepository.Categories.FirstOrDefault(c => c.CategoryName == category).CategoryName;
            }

            return View(new FoodsListViewModel
            {
                Foods = foods,
                CurrentCategory = currentCategory
            });
        }

        public IActionResult Details(int id)
        {
            var food = _foodRepository.GetFoodById(id);
            if (food == null)
                return NotFound();

            return View(food);
        }
    }
}
