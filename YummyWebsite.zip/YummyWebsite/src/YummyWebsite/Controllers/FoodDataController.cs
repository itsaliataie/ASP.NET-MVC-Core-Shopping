﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using YummyWebsite.Models;
using YummyWebsite.ViewModels;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace YummyWebsite.Controllers
{
    [Route("api/[controller]")]
    public class FoodDataController : Controller
    {
        private readonly IFoodRepository _foodRepository;

        public FoodDataController(IFoodRepository foodRepository)
        {
            _foodRepository = foodRepository;
        }

        [HttpGet]
        public IEnumerable<FoodViewModel> LoadMoreFoods()
        {
            IEnumerable<Food> dbFoods = null;

            dbFoods = _foodRepository.Foods.OrderBy(f => f.FoodId).Take(10);

            List<FoodViewModel> foods = new List<FoodViewModel>();

            foreach (var dbFood in dbFoods)
            {
                foods.Add(MapDbFoodToFoodViewModel(dbFood));
            }
            return foods;
        }

        private FoodViewModel MapDbFoodToFoodViewModel(Food dbFood)
        {
            return new FoodViewModel()
            {
                FoodId = dbFood.FoodId,
                Name = dbFood.Name,
                Price = dbFood.Price,
                ShortDescription = dbFood.ShortDescription,
                ImageThumbnailUrl = dbFood.ImageThumbnailUrl
            };
        }
    }
}
